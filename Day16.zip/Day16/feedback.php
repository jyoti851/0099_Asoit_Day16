<!DOCTYPE html>
<html>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Feedback</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <form action ="#" method="POST">
            <h2>Feedback Form</h2>
            <input type="text" id="name" name="name" placeholder="Your Name" required><br>
            <input type="email" id="email" name="email" placeholder="Email id" required><br>
            <input type="text" id="phone" name="phone" placeholder="phone no." required><br>
            <textarea id="message"rows="10" name="message" placeholder="Give yoour Feedback" required></textarea><br>
            <button type="submit" name="submit" id="submit">send</button>
        </form>

    </div>
</body>
</html>
<?php
    // getting all values from the HTML form
    if(isset($_POST['submit']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $message = $_POST['message'];
    }

    // database details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "std";

    // creating a connection
    $con = mysqli_connect($servername, $username, $password, $dbname);

    // to ensure that the connection is made
    if (!$con)
    {
        die("Connection failed!" . mysqli_connect_error());
    }

    // using sql to create a data entry query
    $sql = "INSERT INTO feedback (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
  
    // send query to the database to add values and confirm if successful
    $rs = mysqli_query($con, $sql);
    if($rs)
    {
       
    }
  
    // close connection
    mysqli_close($con);

?>